from setuptools import setup,find_packages

setup(
    name = "src",
    version = "1.0.0",
    description = "wine quality package",
    author = "venkatareddyjillela",
    packages = find_packages(),
    license = "MIT"
)